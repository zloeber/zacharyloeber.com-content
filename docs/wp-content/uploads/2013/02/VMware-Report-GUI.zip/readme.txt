Directories:

Script - The runable gui and actual report generation script. Globals.ps1 is required for the report generation script.

Project - The entire Sapien powershell studio 2012 project. Fancy yourself a coder/hacker? Please feel free to code/hack away. If you make any noteworthy improvements please share with the community and myself like the cool cat that you are!

Zach