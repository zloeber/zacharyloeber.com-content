﻿#region Global functions

#Provides the location of the script
function Get-ScriptDirectory
{ 
	if($hostinvocation -ne $null)
	{
		Split-Path $hostinvocation.MyCommand.path
	}
	else
	{
		Split-Path $script:MyInvocation.MyCommand.Path
	}
}

function Get-FunctionParameters
{
<#
.SYNOPSIS
    Return all parameter elements from a function param() block.

.DESCRIPTION
    This function will return all the parameters defined in a param() portion of a
    script as well as any default values, variable type information, and
    HelpMessage text if present.

.PARAMETER ScriptBlock
    A scriptblock containing a parameter set

.EXAMPLE
    Get-FunctionParameter $Script

.NOTES
Name            :  Get-FunctionParameters
Author          :  Zachary Loeber
Last edit       :  05/31/2013 
Version         :  1.0.0 05/31/2013
                     - First release
Known issues    :  Cannot determine parameters if element is a scriptblock with a default value set.
Disclaimer      :   
    This script is provided AS IS without warranty of any kind. I disclaim all implied warranties including,
    without limitation, any implied warranties of merchantability or of fitness for a particular purpose. 
    The entire risk arising out of the use or performance of the sample scripts and documentation remains
    with you. In no event shall I be liable for any damages whatsoever (including, without limitation, damages 
    for loss of business profits, business interruption, loss of business information, or other pecuniary loss)
    arising out of the use of or inability to use the script or documentation. 
To improve      :   ???
Copyright       :   I believe in sharing knowledge, so this script and its use is subject to : 
                    http://creativecommons.org/licenses/by-sa/3.0/

.LINK
    http://the-little-things.net

.LINK
    http://nl.linkedin.com/in/zloeber
#>
    [CmdletBinding()]
    param
    (
        [Parameter( Mandatory=$true,
                    ValueFromPipeline=$false,
                    HelpMessage="A scriptblock containing a parameter set")]
        [String]$ScriptBlock
    )
	$ScriptBlock = [Scriptblock]::Create($ScriptBlock)
    $paramset = @()
    $tokens = [Management.Automation.PSParser]::Tokenize($ScriptBlock, [ref]$null) | Where {$_.Type -ne 'NewLine'}
    $paramsearch = $false
    $groupstart = 0
    $groupend = 0
    for ($i = 0; $i -lt $tokens.Count; $i++) {
        if (!$paramsearch)
        {
            if ($tokens[$i].Content -eq "param" )
            {
                $paramsearch = $true
            }
        }
        if ($paramsearch)
        {
            if (($tokens[$i].Type -eq "GroupStart") -and ($tokens[$i].Content -eq '(') )
            {
                $groupstart++
            }
            if (($tokens[$i].Type -eq "GroupEnd") -and ($tokens[$i].Content -eq ')') )
            {
                $groupend++
            }
            if (($groupstart -ge 1) -and ($groupstart -eq $groupend))
            {
                $paramsearch = $false
            }
            $isparameter = $false
            $paramdatatype = ''
            $defaultvalue = ''
            if (($tokens[$i].Type -eq 'Variable') -and ($tokens[($i-1)].Content -ne '='))
            {
                if ((($groupstart - $groupend) -eq 1))
                {
                    $isparameter = $true
                }
            }
            if ($isparameter)
            {
                # if assigned, get the parameter default value
                if (($tokens[($i+1)].Type -eq 'Operator') -and ($tokens[($i+1)].Content -eq '='))
                {
                    $defaultvalue = $tokens[($i+2)].Content
                }
                
                # Get the parameter data type
                if (($tokens[($i-1)].Type -eq 'Type'))
                {
                    $paramdatatype = $tokens[($i-1)].Content
                }
            }
            $objprop = @{ 'Type' = $tokens[$i].Type;
                      'Content' = $tokens[$i].Content;
                      'IsParameter' = $isparameter;
                      'ParameterVariableType' = $paramdatatype;
                      'ParamDefaultValue' = $defaultvalue;
                      'HelpMessage' = '';
                    }
            $newobj = New-Object PSObject -Property $objprop
            $paramset = $paramset + $newobj
        }
    }

    # Find all help messages associated with each parameter
    $i=0
    Foreach ($param_item in $paramset)
    {
        if ($param_item.IsParameter)
        {
            $lookforhelptext = $true
            $helpsearch = $i
            While ($lookforhelptext)
            {
                $helpsearch--
                if(($paramset[$helpsearch].IsParameter) -or (($paramset[$helpsearch].Type -eq 'Keyword') -and ($paramset[$helpsearch].Content -eq 'param')) -or ($helpsearch -eq 0))
                {
                    $lookforhelptext = $false
                }
                elseif (($paramset[$helpsearch].Content -eq 'HelpMessage') -and ($paramset[$helpsearch].Type -eq 'Member'))
                {
                    $param_item.HelpMessage = $paramset[($helpsearch+2)].Content
                }
            }
        }
        $i++
    }
    $paramset | where {($_.IsParameter)}
}

Function Get-SaveData
{
    [xml]$x=($ConfigTemplate) -f
        $varchkCustomHeader, `
        $vartxtCustomHeader, `
        $varchkSynopsis, `
        $vartxtSynopsis, `
        $varchkDescription, `
        $vartxtDescription, `
        $varchkInputs, `
        $vartxtInputs, `
        $varchkOutputs, `
        $vartxtOutputs, `
        $varchkExample, `
        $vartxtExample, `
        $varchkNotes, `
        $vartxtNotes, `
        $varchkLink, `
        $vartxtLink, `
        $varchkCustomFooter, `
        $vartxtCustomFooter
    return $x
}

function Load-Config
{
	if (Test-Path $ConfigFile)
	{
		#[xml]$configuration = get-content $($ConfigFile)
        [xml]$configuration = [xml]([System.IO.File]::ReadAllText($ConfigFile))
        $Script:varchkCustomHeader = [System.Convert]::ToBoolean($configuration.Configuration.chkCustomHeader)
        $Script:vartxtCustomHeader = $configuration.Configuration.txtCustomHeader
        $Script:varchkSynopsis = [System.Convert]::ToBoolean($configuration.Configuration.chkSynopsis)
        $Script:vartxtSynopsis = $configuration.Configuration.txtSynopsis
        $Script:varchkDescription = [System.Convert]::ToBoolean($configuration.Configuration.chkDescription)
        $Script:vartxtDescription = $configuration.Configuration.txtDescription
        $Script:varchkInputs = [System.Convert]::ToBoolean($configuration.Configuration.chkInputs)
        $Script:vartxtInputs = $configuration.Configuration.txtInputs
        $Script:varchkOutputs = [System.Convert]::ToBoolean($configuration.Configuration.chkOutputs)
        $Script:vartxtOutputs = $configuration.Configuration.txtOutputs
        $Script:varchkExample = [System.Convert]::ToBoolean($configuration.Configuration.chkExample)
        $Script:vartxtExample = $configuration.Configuration.txtExample
        $Script:varchkNotes = [System.Convert]::ToBoolean($configuration.Configuration.chkNotes)
        $Script:vartxtNotes = $configuration.Configuration.txtNotes
        $Script:varchkLink = [System.Convert]::ToBoolean($configuration.Configuration.chkLink)
        $Script:vartxtLink = $configuration.Configuration.txtLink
        $Script:varchkCustomFooter = [System.Convert]::ToBoolean($configuration.Configuration.chkCustomFooter)
        $Script:vartxtCustomFooter= $configuration.Configuration.txtCustomFooter
        Return $true
	}
    else
    {
        Return $false
    }
}

function Load-Defaults
{
    $Script:varchkCustomHeader = $varDefault.chkCustomHeader
    $Script:vartxtCustomHeader = $varDefault.txtCustomHeader   
    $Script:varchkSynopsis = $varDefault.chkSynopsis
    $Script:vartxtSynopsis = $varDefault.txtSynopsis       
    $Script:varchkDescription = $varDefault.chkDescription
    $Script:vartxtDescription = $varDefault.txtDescription   
    $Script:varchkInputs = $varDefault.chkInputs
    $Script:vartxtInputs = $varDefault.txtInputs
    $Script:varchkOutputs = $varDefault.chkOutputs
    $Script:vartxtOutputs = $varDefault.txtOutputs
    $Script:varchkExample = $varDefault.chkExample
    $Script:vartxtExample = $varDefault.txtExample
    $Script:varchkNotes = $varDefault.chkNotes
    $Script:vartxtNotes = $varDefault.txtNotes
    $Script:varchkLink = $varDefault.chkLink
    $Script:vartxtLink = $varDefault.txtLink
    $Script:varchkCustomFooter = $varDefault.chkCustomFooter
    $Script:vartxtCustomFooter = $varDefault.txtCustomFooter
}

# Save exceptions
function Save-Config
{
    $SanitizedConfig = $true
    
    #
    # Do whatever config testing you want here 
    #
    
    if ($SanitizedConfig)
	{
		# save the data
		[xml]$x=Get-SaveData
        $x.save($ConfigFile)
        Return $true
	}
    else
    {
        Return $false
	}
}
#endregion Global functions

#region Global variables

#Provides the location of the script
[string]$ScriptDirectory = Get-ScriptDirectory

#Config file location
$ConfigFile = $ScriptDirectory + "\Config.xml"

## Globals ##
$varDefault = 
@{   chkCustomHeader	= $false;
     txtCustomHeader	= "    Your custom header";
     chkSynopsis		= $true;
     txtSynopsis		= "    A brief description of the function or script. This keyword can be used`r`n    only once in each topic.";
     chkDescription		= $true;
     txtDescription		= "    A detailed description of the function or script. This keyword can`r`n    used only once in each topic.";
     chkInputs			= $false;
     txtInputs			= "    The Microsoft .NET Framework types of objects that can be piped to the`r`n    function or script. You can also include a description of the input `r`n    objects.";
     chkOutputs			= $false;
     txtOutputs			= "    The .NET Framework type of the objects that the cmdlet returns. You can`r`n    also include a description of the returned objects.";
     chkExample			= $true;
     txtExample			= "    A sample command that uses the function or script, optionally followed`r`n    by sample output and a description. Repeat this keyword for each example.";
     chkNotes			= $true;
     txtNotes			= "    Additional information about the function or script.";
     chkLink			= $true;
     txtLink			= "    The name of a related topic. The value appears on the line below`r`n    the .LINE keyword and must be preceded by a comment symbol (#) or`r`n    included in the comment block.`r`n`r`n    Repeat the .LINK keyword for each related topic.`r`n`r`n    This content appears in the Related Links section of the help topic.`r`n`r`n    The Link keyword content can also include a Uniform Resource Identifier`r`n    (URI) to an online version of the same help topic. The online version`r`n    opens when you use the Online parameter of Get-Help. The URI must begin`r`n    with http or https.";
     chkCustomFooter	= $false;
     txtCustomFooter	= '    Your custom footer';
}

$varchkCustomHeader = $true
$vartxtCustomHeader = ''
$varchkSynopsis = $true
$vartxtSynopsis = ''
$varchkDescription = $true
$vartxtDescription = ''
$varchkInputs = $true
$vartxtInputs = ''
$varchkOutputs = $true
$vartxtOutputs = ''
$varchkExample = $true
$vartxtExample = ''
$varchkNotes = $true
$vartxtNotes = ''
$varchkLink = $true
$vartxtLink = ''
$varchkCustomFooter = $true
$vartxtCustomFooter = ''

#For each variable an xml attribute should exist
$ConfigTemplate = 
@"
<Configuration>
    <chkCustomHeader>{0}</chkCustomHeader>
    <txtCustomHeader>{1}</txtCustomHeader>
	<chkSynopsis>{2}</chkSynopsis>
	<txtSynopsis>{3}</txtSynopsis>
	<chkDescription>{4}</chkDescription>
	<txtDescription>{5}</txtDescription>
	<chkInputs>{6}</chkInputs>
	<txtInputs>{7}</txtInputs>
    <chkOutputs>{8}</chkOutputs>
    <txtOutputs>{9}</txtOutputs>
    <chkExample>{10}</chkExample>
    <txtExample>{11}</txtExample>
    <chkNotes>{12}</chkNotes>
    <txtNotes>{13}</txtNotes>
    <chkLink>{14}</chkLink>
	<txtLink>{15}</txtLink>
	<chkCustomFooter>{16}</chkCustomFooter>
	<txtCustomFooter>{17}</txtCustomFooter>
</Configuration>
"@
